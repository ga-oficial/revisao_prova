import BuscaCep from "../components/BuscaCep";

export default function Cep(){
    return(
        <BuscaCep />
    )
}